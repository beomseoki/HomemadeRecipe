package com.myapp.homemaderecipe.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.cachedIn
import com.myapp.homemaderecipe.data.repository.AppDatabase

class MainViewModel : ViewModel() {

    val recipes by lazy {
        Pager(
            PagingConfig(pageSize = 10)
        ) {
            AppDatabase.getInstance().recipeDao().getRecipes()
        }.flow
            .cachedIn(viewModelScope)
    }
}