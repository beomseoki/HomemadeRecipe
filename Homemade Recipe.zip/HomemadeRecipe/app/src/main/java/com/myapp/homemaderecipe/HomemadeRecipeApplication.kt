package com.myapp.homemaderecipe

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context


class HomemadeRecipeApplication : Application() {

    companion object {
        @SuppressLint("StaticFieldLeak")
        public lateinit var appCtx: Context
            private set
    }

    override fun onCreate() {
        super.onCreate()

        appCtx = this
    }
}