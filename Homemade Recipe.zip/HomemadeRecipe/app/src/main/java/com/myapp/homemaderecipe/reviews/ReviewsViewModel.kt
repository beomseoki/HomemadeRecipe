package com.myapp.homemaderecipe.reviews

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.cachedIn
import com.myapp.homemaderecipe.data.model.Review
import com.myapp.homemaderecipe.data.repository.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

class ReviewsViewModel : ViewModel() {

    val reviews by lazy {
        Pager(
            PagingConfig(pageSize = 10)
        ) {
            AppDatabase.getInstance().reviewDao().getReviews()
        }.flow
            .cachedIn(viewModelScope)
    }

    fun add(name: String, message: String) {
        val review = Review(
            name = name,
            message = message,
            date = Date().time
        )

        viewModelScope.launch(Dispatchers.IO) {
            AppDatabase.getInstance().reviewDao().insertReviews(review)
        }
    }

    fun modify(oldReview: Review, name: String, message: String) {
        val review = Review(
            id = oldReview.id,
            name = name,
            message = message,
            date = oldReview.date
        )

        viewModelScope.launch(Dispatchers.IO) {
            AppDatabase.getInstance().reviewDao().updateReview(review)
        }
    }

    fun remove(review: Review) {
        viewModelScope.launch(Dispatchers.IO) {
            AppDatabase.getInstance().reviewDao().deleteReview(review)
        }
    }
}