package com.myapp.homemaderecipe.main

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.util.Consumer
import androidx.lifecycle.lifecycleScope
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myapp.homemaderecipe.HomemadeRecipeApplication.Companion.appCtx
import com.myapp.homemaderecipe.data.model.Recipe
import com.myapp.homemaderecipe.databinding.ActivityMainBinding
import com.myapp.homemaderecipe.databinding.ItemRecipeBinding
import com.myapp.homemaderecipe.reviews.ReviewsActivity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch


class MainActivity : AppCompatActivity() {

    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }
    private val viewModel: MainViewModel by viewModels()
    private val adapter by lazy { RecipeAdapter() }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        initUi()
    }

    private fun initUi() = with(binding) {
        recyclerView.layoutManager = GridLayoutManager(this@MainActivity, 2)
        recyclerView.adapter = adapter
        adapter.onClickListener = Consumer {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(it.url)
            }

            startActivity(intent)
        }

        reviewsButton.setOnClickListener {
            startActivity(Intent(this@MainActivity, ReviewsActivity::class.java).apply {
                flags = flags or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            })
        }

        lifecycleScope.launch {
            viewModel.recipes.collectLatest {
                adapter.submitData(it)
            }
        }
    }


    private class RecipeAdapter : PagingDataAdapter<Recipe, RecipeAdapter.RecipeItemViewHolder>(diffCallback) {

        companion object {
            val diffCallback
                get() = object : DiffUtil.ItemCallback<Recipe>() {
                    override fun areItemsTheSame(oldItem: Recipe, newItem: Recipe): Boolean {
                        return oldItem.id == newItem.id
                    }

                    override fun areContentsTheSame(oldItem: Recipe, newItem: Recipe): Boolean {
                        return oldItem.name == newItem.name &&
                                oldItem.picture == newItem.picture &&
                                oldItem.url == newItem.url
                    }
                }
        }

        var onClickListener: Consumer<Recipe>? = null

        override fun onBindViewHolder(holder: RecipeItemViewHolder, position: Int) {
            val recipe = getItem(position)!!

            with(holder.binding) {
                val resId = appCtx.resources.getIdentifier(recipe.picture, "drawable", appCtx.packageName)
                imageView.setImageResource(resId)
                nameTextView.text = recipe.name

                imageContainer.setOnClickListener {
                    onClickListener?.accept(recipe)
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipeItemViewHolder {
            val layoutInflater = LayoutInflater.from(parent.context)
            return RecipeItemViewHolder(ItemRecipeBinding.inflate(layoutInflater, parent, false))
        }

        class RecipeItemViewHolder(val binding: ItemRecipeBinding) : RecyclerView.ViewHolder(binding.root)
    }
}