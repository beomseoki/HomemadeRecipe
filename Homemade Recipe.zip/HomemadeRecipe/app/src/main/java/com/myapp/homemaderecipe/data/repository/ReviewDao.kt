package com.myapp.homemaderecipe.data.repository

import androidx.paging.PagingSource
import androidx.room.*
import com.myapp.homemaderecipe.data.model.Recipe
import com.myapp.homemaderecipe.data.model.Review

@Dao
interface ReviewDao {
    // @Query("SELECT * FROM recipe LIMIT 10 OFFSET 10 * :index ORDER BY name")
    @Query("SELECT * FROM review ORDER BY date DESC")
    fun getReviews(): PagingSource<Int, Review>

    @Insert
    fun insertReviews(vararg review: Review)

    @Update
    fun updateReview(review: Review)

    @Delete
    fun deleteReview(review: Review)
}