package com.myapp.homemaderecipe.data.repository

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.myapp.homemaderecipe.HomemadeRecipeApplication.Companion.appCtx
import com.myapp.homemaderecipe.data.model.Recipe
import com.myapp.homemaderecipe.data.model.Review
import java.util.concurrent.Executors


@Database(entities = [Recipe::class, Review::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(): AppDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(appCtx, AppDatabase::class.java, "recipe")
                    .fallbackToDestructiveMigration()
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)

                            Executors.newSingleThreadExecutor().execute {
                                with(instance!!.recipeDao()) {
                                    insertRecipes(
                                        Recipe(
                                            name = "치즈간장계란밥",
                                            picture = "recipe_cheese_soy_sauce_egg_rice",
                                            url = "https://www.youtube.com/watch?v=9HrJKJwZTFo"
                                        ),
                                        Recipe(
                                            name = "아웃백투움바 파스타레시피",
                                            picture = "recipe_outbag_toowoomba_pasta",
                                            url = "https://m.blog.naver.com/guritire1/222272983353"
                                        ),
                                        Recipe(
                                            name = "초간단 버전 김치찌개",
                                            picture = "recipe_super_simple_kimchi_stew",
                                            url = "https://appleboxx.kr/entry/%EB%8F%BC%EC%A7%80%EA%B3%A0%EA%B8%B0-%EA%B9%80%EC%B9%98%EC%B0%8C%EA%B0%9C-%EB%A7%9B%EC%9E%88%EA%B2%8C-%EB%A7%8C%EB%93%9C%EB%8A%94-%EB%B0%A9%EB%B2%95-%EB%B0%B1%EC%A2%85%EC%9B%90"
                                        ),
                                        Recipe(
                                            name = "초간단 국수레시피",
                                            picture = "recipe_super_simple_noodle",
                                            url = "https://m.blog.naver.com/PostView.naver?blogId=guritire1&logNo=222433828898&referrerCode=0&searchKeyword=%EB%A0%88%EC%8B%9C%ED%94%BC"
                                        ),
                                    )
                                }
                            }
                        }
                    })
                    .build().also {
                        instance = it
                    }
            }
        }
    }

    abstract fun recipeDao(): RecipeDao
    abstract fun reviewDao(): ReviewDao
}