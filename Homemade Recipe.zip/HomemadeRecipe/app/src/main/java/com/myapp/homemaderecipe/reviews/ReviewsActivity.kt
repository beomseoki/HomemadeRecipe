package com.myapp.homemaderecipe.reviews

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.util.Consumer
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.myapp.homemaderecipe.data.model.Review
import com.myapp.homemaderecipe.databinding.ActivityReviewsBinding
import com.myapp.homemaderecipe.databinding.ItemReviewBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*


class ReviewsActivity : AppCompatActivity() {

    private val binding by lazy { ActivityReviewsBinding.inflate(layoutInflater) }
    private val viewModel: ReviewsViewModel by viewModels()
    private val adapter by lazy { ReviewAdapter() }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        initUi()
    }

    private fun initUi() = with(binding) {
        toolbar.setNavigationOnClickListener { onBackPressed() }

        recyclerView.apply {
            this.adapter = this@ReviewsActivity.adapter
            addItemDecoration(DividerItemDecoration(this@ReviewsActivity, LinearLayoutManager.VERTICAL))
        }

        with(adapter) {
            onClickListener = Consumer {
                ReviewEditorActivity.startActivity(this@ReviewsActivity, it)
            }

            registerAdapterDataObserver(object : RecyclerView.AdapterDataObserver() {
                private fun setEmptyViewVisibility() {
                    emptyView.isVisible = adapter.itemCount == 0
                }

                override fun onChanged() {
                    super.onChanged()
                    setEmptyViewVisibility()
                }

                override fun onItemRangeInserted(positionStart: Int, itemCount: Int) {
                    super.onItemRangeInserted(positionStart, itemCount)
                    setEmptyViewVisibility()
                }

                override fun onItemRangeRemoved(positionStart: Int, itemCount: Int) {
                    super.onItemRangeRemoved(positionStart, itemCount)
                    setEmptyViewVisibility()
                }
            })
        }

        reviewsButton.setOnClickListener {
            ReviewEditorActivity.startActivity(this@ReviewsActivity)
        }

        lifecycleScope.launch {
            viewModel.reviews.collectLatest {
                adapter.submitData(it)
            }
        }
    }


    private class ReviewAdapter : PagingDataAdapter<Review, ReviewAdapter.ReviewItemViewHolder>(diffCallback) {

        companion object {
            val diffCallback
                get() = object : DiffUtil.ItemCallback<Review>() {
                    override fun areItemsTheSame(oldItem: Review, newItem: Review): Boolean {
                        return oldItem.id == newItem.id
                    }

                    override fun areContentsTheSame(oldItem: Review, newItem: Review): Boolean {
                        return oldItem.name == newItem.name &&
                                oldItem.message == newItem.message &&
                                oldItem.date == newItem.date
                    }
                }
        }

        private val dateFormatter by lazy { SimpleDateFormat("yy/MM/dd a hh:mm", Locale.KOREAN) }
        var onClickListener: Consumer<Review>? = null

        override fun onBindViewHolder(holder: ReviewItemViewHolder, position: Int) {
            val review = getItem(position)!!

            with(holder.binding) {
                nameTextView.text = review.name
                messageTextView.text = review.message
                dateTextView.text = dateFormatter.format(Date(review.date))

                root.setOnClickListener {
                    onClickListener?.accept(review)
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReviewItemViewHolder {
            val layoutInflater = LayoutInflater.from(parent.context)
            return ReviewItemViewHolder(ItemReviewBinding.inflate(layoutInflater, parent, false))
        }

        class ReviewItemViewHolder(val binding: ItemReviewBinding) : RecyclerView.ViewHolder(binding.root)
    }
}