package com.myapp.homemaderecipe.reviews

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.myapp.homemaderecipe.R
import com.myapp.homemaderecipe.data.model.Review
import com.myapp.homemaderecipe.databinding.ActivityReviewEditorBinding


class ReviewEditorActivity : AppCompatActivity() {

    companion object {
        private val ARG_REVIEW = "ARG_REVIEW"

        fun startActivity(context: Context, review: Review? = null) {
            val intent = Intent(context, ReviewEditorActivity::class.java).apply {
                flags = flags or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(ARG_REVIEW, review)
            }

            context.startActivity(intent)
        }
    }

    private val binding by lazy { ActivityReviewEditorBinding.inflate(layoutInflater) }
    private var review: Review? = null
    private val viewModel: ReviewsViewModel by viewModels()
    private val isEditMode: Boolean
        get() = review != null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        review = intent?.getParcelableExtra(ARG_REVIEW)

        if (savedInstanceState != null) {
            review = savedInstanceState.getParcelable(ARG_REVIEW)
        }

        initUi()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putParcelable(ARG_REVIEW, review)
        super.onSaveInstanceState(outState)
    }

    private fun initUi() = with(binding) {
        with(toolbar) {
            setNavigationOnClickListener { onBackPressed() }
            setOnMenuItemClickListener {
                MaterialAlertDialogBuilder(this@ReviewEditorActivity)
                    .setMessage("이 리뷰를 삭제하시겠습니까?")
                    .setPositiveButton("확인") { _, _ ->
                        viewModel.remove(review!!)
                        Toast.makeText(this@ReviewEditorActivity, "리뷰가 삭제되었습니다.", Toast.LENGTH_SHORT).show()
                        onBackPressed()
                    }
                    .setNegativeButton("취소", null)
                    .show()

                false
            }

            menu.findItem(R.id.action_remove).isVisible = isEditMode
        }

        nameTextField.editText!!.addTextChangedListener {
            doneButton.isEnabled = nameTextField.editText!!.text.toString().isNotBlank() &&
                    messageTextField.editText!!.text.toString().isNotBlank()
        }

        messageTextField.editText!!.addTextChangedListener {
            doneButton.isEnabled = nameTextField.editText!!.text.toString().isNotBlank() &&
                    messageTextField.editText!!.text.toString().isNotBlank()
        }

        with(doneButton) {
            text = if (isEditMode) "수정" else "입력"
            setOnClickListener {
                val name = nameTextField.editText!!.text.toString().trim()
                val message = messageTextField.editText!!.text.toString().trim()

                if (review == null) {
                    viewModel.add(name, message)
                    Toast.makeText(this@ReviewEditorActivity, "리뷰가 추가되었습니다.", Toast.LENGTH_SHORT).show()

                } else {
                    viewModel.modify(review!!, name, message)
                    Toast.makeText(this@ReviewEditorActivity, "리뷰가 수정되었습니다.", Toast.LENGTH_SHORT).show()
                }

                finish()
            }
        }

        if (isEditMode) {
            nameTextField.editText!!.append(review!!.name)
            messageTextField.editText!!.append(review!!.message)
        }
    }
}