package com.myapp.homemaderecipe.data.repository

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.myapp.homemaderecipe.data.model.Recipe

@Dao
interface RecipeDao {
    // @Query("SELECT * FROM recipe LIMIT 10 OFFSET 10 * :index ORDER BY name")
    @Query("SELECT * FROM recipe ORDER BY name")
    fun getRecipes(): PagingSource<Int, Recipe>

    @Insert
    fun insertRecipes(vararg recipe: Recipe)
}